document.addEventListener('DOMContentLoaded', function() {

    // Grab Elements
    const btn       = document.querySelector('#selectedOption');
    const menu      = document.querySelector('.optionsContainer');
    const options   =   document.querySelectorAll('.options');

    // Open/Close Btn 
    btn.addEventListener('click', function() {
        menu.classList.toggle('active');
    })

    // Select Option
    options.forEach(function(option){
        option.addEventListener('click', function(op){
            btn.value = op.target.innerText;
        })
    }) 

    // Close Option List on Clicking Outside List
    document.addEventListener('click', function(e) {
        if (e.target.id !== 'selectedOption') {
            menu.classList.remove('active');
        }
    })

});